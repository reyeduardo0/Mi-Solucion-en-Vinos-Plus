
import React, { useState, useEffect } from 'react';
import { User, Role } from '../../types';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Spinner from '../ui/Spinner';
import { useData } from '../../context/DataContext';
import { getErrorMessage } from '../../utils/helpers';

interface UserModalProps {
    user: User | null;
    roles: Role[];
    onSave: (user: (Omit<User, 'id'> & { password?: string }) | User, newPassword?: string) => Promise<void>;
    onClose: () => void;
}

const SUPER_USER_EMAIL = 'reyeduardo0@gmail.com';

const UserModal: React.FC<UserModalProps> = ({ user, roles, onSave, onClose }) => {
    const { currentUser } = useData();
    const [name, setName] = useState(user?.name || '');
    const [email, setEmail] = useState(user?.email || '');
    const [roleId, setRoleId] = useState(user?.roleId || '');
    const [password, setPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const isEditingSuperUser = user?.email === SUPER_USER_EMAIL;
    const amISuperUser = currentUser?.email === SUPER_USER_EMAIL;
    
    // Lógica de permisos para editar contraseña:
    // 1. Si es nuevo usuario: SI
    // 2. Si soy yo mismo: SI
    // 3. Si soy Super Usuario: SI (incluso si no soy yo, gracias a las funciones RPC)
    const canChangePassword = !user || (currentUser?.id === user.id) || amISuperUser;

    const isProtectedField = isEditingSuperUser;

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        
        if (!roleId) {
            setError("Por favor, seleccione un rol.");
            return;
        }
        if (!user && !password) {
            setError("La contraseña es obligatoria para nuevos usuarios.");
            return;
        }

        setIsLoading(true);
        setError(null);
        
        try {
            const userData = { name, email, roleId };
            if (user) {
                await onSave({ ...user, ...userData }, newPassword);
            } else {
                await onSave({ ...userData, password });
            }
            onClose();
        } catch (e: any) {
            setError(getErrorMessage(e));
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
        <Modal title={user ? `Editando Usuario: ${user.name}` : 'Crear Nuevo Usuario'} onClose={onClose}>
            <form onSubmit={handleSubmit} className="space-y-4">
                {isEditingSuperUser && (
                    <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4" role="alert">
                        <p className="font-bold">Aviso</p>
                        <p>Estás editando al Super Usuario. El Email y el Rol están bloqueados por seguridad.</p>
                    </div>
                )}
                <div><label className="block text-sm font-medium">Nombre Completo</label><input type="text" value={name} onChange={e => setName(e.target.value)} required className="mt-1 block w-full border-gray-300 rounded-md shadow-sm p-2" /></div>
                <div><label className="block text-sm font-medium">Correo Electrónico</label><input type="email" value={email} onChange={e => setEmail(e.target.value)} required disabled={!!user || isProtectedField} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm p-2 disabled:bg-gray-100" /></div>
                
                {!user && (<div><label className="block text-sm font-medium">Contraseña</label><input type="password" value={password} onChange={e => setPassword(e.target.value)} required={!user} placeholder="Mínimo 6 caracteres" className="mt-1 block w-full border-gray-300 rounded-md shadow-sm p-2" /></div>)}
                
                {user && canChangePassword && (
                    <div>
                        <label className="block text-sm font-medium">Nueva Contraseña (Opcional)</label>
                        <input 
                            type="password" 
                            value={newPassword} 
                            onChange={e => setNewPassword(e.target.value)} 
                            placeholder="Dejar en blanco para no cambiar" 
                            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm p-2" 
                        />
                        {amISuperUser && user.id !== currentUser?.id && (
                            <p className="text-xs text-blue-600 mt-1">Como Super Usuario, puedes sobrescribir la contraseña de este usuario.</p>
                        )}
                    </div>
                )}
                
                {user && !canChangePassword && (
                    <div className="bg-gray-100 p-3 rounded text-sm text-gray-600 italic">
                        No tienes permisos para cambiar la contraseña de este usuario.
                    </div>
                )}

                <div><label className="block text-sm font-medium">Rol</label><select value={roleId} onChange={e => setRoleId(e.target.value)} required disabled={isProtectedField} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm p-2 disabled:bg-gray-100"><option value="">Seleccionar un rol...</option>{roles.map(r => <option key={r.id} value={r.id} disabled={r.name === 'Super Usuario' && !isEditingSuperUser}>{r.name}</option>)}</select></div>
                
                {error && <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">{error}</div>}

                <div className="flex justify-end space-x-3 pt-4 border-t">
                    <Button type="button" variant="secondary" onClick={onClose} disabled={isLoading}>Cancelar</Button>
                    <Button type="submit" disabled={isLoading}>
                        {isLoading ? <Spinner/> : (user ? 'Guardar Cambios' : 'Crear Usuario')}
                    </Button>
                </div>
            </form>
        </Modal>
    );
};

export default UserModal;
